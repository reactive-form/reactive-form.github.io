/*!
 * form-priestess 0.1.5 | Models iife | https://jilinxiangyun.com
 * Copyright 2021 JLxiangyun | MIT license
 */
var Priestess=(()=>{var d=Object.defineProperty;var l=t=>d(t,"__esModule",{value:!0});var a=(t,e)=>{l(t);for(var o in e)d(t,o,{get:e[o],enumerable:!0})};var r={};a(r,{default:()=>p});var f={},p=f;return r;})();
//# sourceMappingURL=form-priestess.models.iife.min.js-c9b3f467.map
