/*!
 * rcfm 0.2.1 | React iife | https://jilinxiangyun.com
 * Copyright 2021 JLxiangyun | MIT license
 */
(()=>{(()=>{let r=window.require,i=e=>({"rcfm/helper":{UI:window.ReactiveForm.UI},react:window.React,"react-dom":window.ReactDOM})[e];window.require=e=>r&&r(e)||i(e)})();})();
//# sourceMappingURL=rcfm.react.iife.min.js-192c248c.map
