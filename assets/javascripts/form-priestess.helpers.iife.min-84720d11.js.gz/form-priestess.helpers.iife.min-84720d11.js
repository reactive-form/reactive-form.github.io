/*!
 * form-priestess 0.1.5 | Helpers iife | https://jilinxiangyun.com
 * Copyright 2021 JLxiangyun | MIT license
 */
(()=>{var p=Object.create;var i=Object.defineProperty;var w=Object.getOwnPropertyDescriptor;var d=Object.getOwnPropertyNames;var f=Object.getPrototypeOf,m=Object.prototype.hasOwnProperty;var n=e=>i(e,"__esModule",{value:!0});var l=e=>{if(typeof require!="undefined")return require(e);throw new Error('Dynamic require of "'+e+'" is not supported')};var u=(e,r,o)=>{if(r&&typeof r=="object"||typeof r=="function")for(let s of d(r))!m.call(e,s)&&s!=="default"&&i(e,s,{get:()=>r[s],enumerable:!(o=w(r,s))||o.enumerable});return e},q=e=>u(n(i(e!=null?p(f(e)):{},"default",e&&e.__esModule&&"default"in e?{get:()=>e.default,enumerable:!0}:{value:e,enumerable:!0})),e);window.require||(window.require=e=>({"form-priestess":window.Priestess})[e]);var t=q(l("form-priestess")),H=t.default.Helpers={},c=H;})();
//# sourceMappingURL=form-priestess.helpers.iife.min.js-c5259713.map
